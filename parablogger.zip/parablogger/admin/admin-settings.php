<div class="wrap">

	<div id="icon-tools" class="icon32"><br></div><?php echo "<h2>".__(parablogger_name.' Help & Support','parablogger')."</h2>";?>
 
<?php

	$slug_options_id = 'parablogger_options';

	$slug_options_tabs = array(
								'tab1'=>'Help & Support',

								);

	$slug_options['tab1'] = array(
	
	
	
					'help_text'=>array(
						'css_class'=>'help_text',					
						'title'=>'ParaBlogger help',
						'option_details'=>'Feel free to Contact with any issue for this Theme, Ask any question via forum <a href="http://paratheme.com/qa/">http://paratheme.com/qa/</a> <strong style="color:#139b50;">(free)</strong>',						
						'input_type'=>'', // text, radio, checkbox, select, 
						'input_values'=>'', // could be array							
						),
	
	

						
						
					);
					
					
					
	$slug_display = new paraAdmin();
	
	echo $slug_display->option_output($slug_options_id, $slug_options, $slug_options_tabs) ;
	
	



?>

</div>

<style type="text/css">
.submit{
	display:none;}
</style>