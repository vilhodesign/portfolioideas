=== ParaBlogger ===

Contributors: automattic
Tags: translation-ready, custom-background, theme-options, custom-menu, post-formats, threaded-comments

Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

ParaBlogger is ready for bloggers, writers who write blog/post daily.

== Description ==

ParaBlogger is perfect for blogger witers who write daily blog or post. an amazing header will give your blog nice look. you can change header image from settings as your wish.
Custom menu at header and widget support at footer.
Also support archive page for category, tags, author and etc.

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

ParaBlogger includes support for Infinite Scroll in Jetpack.

== Changelog ==

= 1.0.3 - 20/06/2015 =
* remove admin settings for header.
* move header image to customizer.


= 1.0.2 - 12/06/2015 =
* Themes description rewritten at style.css file.

= 1.0.1 - 12/06/2015 =
* removed rtl.css file.
* custom-header.php removed.
* removed README.md file.
* description rewritten.

= 1.0 - May 12 2015 =
* Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

Images are licensed GNU General Public License v2 or later

parablogger/images/cover-wp.png
parablogger/screenshot.png
image link:http://www.freepik.com/free-vector/hot-air-balloon-in-the-sky-vector_722145.htm